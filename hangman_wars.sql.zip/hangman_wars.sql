-- phpMyAdmin SQL Dump
-- version 4.4.10
-- http://www.phpmyadmin.net
--
-- Host: localhost:8889
-- Generation Time: Mar 08, 2017 at 10:34 PM
-- Server version: 5.5.42
-- PHP Version: 5.6.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hangman_wars`
--
CREATE DATABASE IF NOT EXISTS `hangman_wars` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `hangman_wars`;

-- --------------------------------------------------------

--
-- Table structure for table `authors`
--

CREATE TABLE `authors` (
  `id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `authors`
--

INSERT INTO `authors` (`id`, `name`) VALUES
(1, 'shakespeare'),
(2, 'dickens'),
(3, 'chaucer'),
(4, 'poe'),
(5, 'woolf'),
(6, 'tolstoy'),
(7, 'twain'),
(8, 'austen'),
(9, 'wilde'),
(10, 'napoleon'),
(11, 'hemingway'),
(12, 'stevenson'),
(13, 'python'),
(14, 'star wars');

-- --------------------------------------------------------

--
-- Table structure for table `game_state`
--

CREATE TABLE `game_state` (
  `id` bigint(20) unsigned NOT NULL,
  `current_score` int(11) DEFAULT NULL,
  `realm_one` tinyint(1) DEFAULT NULL,
  `realm_two` tinyint(1) DEFAULT NULL,
  `realm_three` tinyint(1) DEFAULT NULL,
  `realm_four` tinyint(1) DEFAULT NULL,
  `realm_five` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `game_state`
--

INSERT INTO `game_state` (`id`, `current_score`, `realm_one`, `realm_two`, `realm_three`, `realm_four`, `realm_five`) VALUES
(1, 100, 0, 0, 0, 0, 0),
(2, 100, 1, 0, 0, 0, 0),
(3, 80, 1, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `phrases`
--

CREATE TABLE `phrases` (
  `id` bigint(20) unsigned NOT NULL,
  `phrase` text,
  `author_id` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `phrases`
--

INSERT INTO `phrases` (`id`, `phrase`, `author_id`) VALUES
(1, 'Fear is the path to the dark side', 14),
(3, 'Be not afraid of greatness. Some are born great, some achieve greatness, and some have greatness thrust upon them.', 1),
(5, 'Brevity is the soul of wit.', 1),
(6, 'Drink provokes the desire but takes away the performance.', 1),
(8, 'It is a custom more honored in the breach than the observance.', 1),
(9, 'Readiness is all.', 1),
(10, 'We forge the chains we wear in life.', 2),
(12, 'He would make a lovely corpse.', 2),
(13, 'A loving heart is the truest wisdom.', 2),
(14, 'It was the best of times, it was the worst of times.', 2),
(15, 'There are strings in the human heart that had better not be vibrated.', 2),
(16, 'There''s never a new fashion but it''s old.', 3),
(17, 'The life so short, the crafts so long to learn.', 3),
(18, 'Time and tide wait for no man.', 3),
(19, 'The guilty think all talk is of themselves.', 3),
(20, 'Forbid us something, and that thing we desire.', 3),
(22, 'Stupidity is a talent for misconception.', 4),
(23, 'We loved with a love that was more than love.', 4),
(24, 'I became insane, with long intervals of horrible sanity.', 4),
(25, 'All that we see or seem is but a dream within a dream.', 4),
(26, 'If you wish to forget anything on the spot, make a note that this thing is to be remembered.', 4),
(27, 'Every savage can dance.', 8),
(28, 'Nothing ever fatigues me but doing what I do not like.', 8),
(29, 'Nobody minds having what is too good for them', 8),
(30, 'Is not general incivility the very essence of love?', 8),
(31, 'The two most powerful warriors are patience and time.', 6),
(32, 'Government is an association of men who do violence to the rest of us.', 6),
(33, 'Historians are like deaf people who go on answering questions that no one has asked them.', 6),
(34, 'Boredom: the desire for desires.', 6),
(35, 'Nietzsche was stupid and abnormal.', 6),
(36, 'Whenever you find yourself on the side of the majority, it is time to pause and reflect.', 7),
(37, 'Get your facts first, then you can distort them as you please.', 7),
(38, 'Honesty is the best policy - when there is money in it.', 7),
(39, 'A person who won''t read has no advantage over someone who can''t.', 7),
(40, 'Martyrdom covers a multitude of sins.', 7),
(41, 'Rigid, the skeleton of habit alone upholds the human frame.', 5),
(42, 'It is far more difficult to murder a phantom than a reality.', 5),
(43, 'Great bodies of people are never responsible for what they do.', 5),
(44, 'The older one grows, the more one likes indecency.', 5),
(46, 'A gentleman is one who never hurts anyone''s feelings unintentionally.', 9),
(47, 'Life is never fair, and perhaps it is a good thing for most of us that it is not.', 9),
(48, 'It is absurd to divide people into good and bad.  People are either charming or tedious.', 9),
(49, 'I think that God, in creating man, somewhat overestimated his ability.', 9),
(50, 'Everyone who is incapable of learning has taken to teaching.', 9),
(51, 'For most of history, Anonymous was a woman.', 5),
(52, 'If you wish to be a success in the world, promise everything, deliver nothing.', 10),
(53, 'A man will fight harder for his interests than his rights.', 10),
(54, 'One should never forbid what one lacks the power to prevent.', 10),
(55, 'Nothing is more difficult, and therefore more precious, than to be able to decide.', 10),
(56, 'Religion is what keeps the poor from murdering the rich.', 10),
(57, 'Hesitation increases in relation to risk in equal proportion to age.', 11),
(58, 'Never think that war, no matter how necessary, nor how justified, is not a crime.', 11),
(59, 'Time is the least thing we have.', 11),
(60, 'Prose is architecture, not interior decoration, and the Baroque is over.', 11),
(61, 'Wars are caused by undefended wealth.', 11),
(62, 'The devil can sometimes do a very gentlemanly thing.', 12),
(63, 'Politics is perhaps the only profession for which no preparation is thought necessary.', 12),
(64, 'Sooner or later everyone sits down to a banquet of consequences.', 12),
(65, 'It is a mark of a good action that it appears inevitable in retrospect.', 12),
(66, 'Marriage: a friendship recognized by the police.', 12),
(68, 'What is the air speed velocity of an unladen swallow?', 13),
(69, 'Strange women lying in ponds distributing swords is no basis for a system of government', 13),
(70, 'I have no choice but to sell you all for scientific experiments.', 13),
(71, 'You don''t have to go leaping straight for the clitoris like a bull at a gate.', 13),
(72, 'Your type really makes me puke, you vacuous, toffy-nosed, malodorous pervert!', 13),
(73, 'Strike me down and I will become more powerful than you could possibly imagine.', 14),
(74, 'Travelling through hyperspace ain''t like dusting crops, farm boy.', 14),
(75, 'I''m afraid the deflector shield will be quite operational when your friends arrive.', 14),
(76, 'Luminous beings are we, not this crude matter.', 14),
(78, 'The pleasantness of an employment does not always evince its propriety.', 8);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `authors`
--
ALTER TABLE `authors`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `game_state`
--
ALTER TABLE `game_state`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `phrases`
--
ALTER TABLE `phrases`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `authors`
--
ALTER TABLE `authors`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `game_state`
--
ALTER TABLE `game_state`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `phrases`
--
ALTER TABLE `phrases`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=79;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
